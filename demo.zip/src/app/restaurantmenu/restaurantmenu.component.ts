import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantmenu',
  templateUrl: './restaurantmenu.component.html',
  styleUrls: ['./restaurantmenu.component.css']
})
export class RestaurantmenuComponent implements OnInit {
  breakfastmenu: string[] = ["Egg Fry", "Idli", "Dosa", "Bread Omlette", "Pongal", "Medu Wada"]
  lunchmenu: string[] = ["South Indian Thali", "North Indian Thali", "Biselbeli Rice", "Curd Rice", "Biryani"]
  bpromotion = "Buy 2 Idlis with Coffee @10% discount, Buttermilk free with Pongal "
  lpromotion = "Any Thali for Rs.60 Only, Combo of 2 thalis Coca-Cola free"
  itemprice: number[] = [100.00, 75.00, 125.00, 85.00, 60.00]
  menuitem: string;
  isbreakfast: boolean = true;
  displaymenu: string[] = []
  cssClass: string = 'redwhite'
  mystyle = {}
  styleToggleFlag: boolean = true;

  setStyle() {
    
    this.mystyle = {
      'font-weight': this.styleToggleFlag ? 'bold' : 'normal',
      'font-size': this.styleToggleFlag ? '24px' : '16px',
      'color': this.generaterandomcolor(),
      'background-color': "white"
    
    }
    this.styleToggleFlag = !this.styleToggleFlag
   }
  color: string = ""
  generaterandomcolor() {
    var colorcodes = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]
    this.color = "#"
    for (let i = 0; i < 6; i++) {
      this.color += colorcodes[Math.floor(Math.random() * 16)]
    }
    console.log(this.color)
    return this.color
  }

  setCssClss() {
    if (this.isbreakfast) {
      this.cssClass = 'redwhite'
    }
    else {
      this.cssClass = "bluegold"
    }
  }

  setItem(m) {
    this.menuitem = m;
    this.setStyle()
  }

  cmenu(mtype) {
    if (mtype == 'L') {
      this.displaymenu = this.lunchmenu
      this.isbreakfast = false
    }
    else {
      this.displaymenu = this.breakfastmenu
      this.isbreakfast = true
    }
    this.setCssClss()
  }

  constructor() { }

  ngOnInit(): void {
    this.displaymenu = this.breakfastmenu
    /*this.mystyle = {
      'font-weight': 'bold',
      'font-size': '24px',
      'color': 'darkblue',
      'background-color': 'white'
    }*/
    this.setStyle()

  }

}
