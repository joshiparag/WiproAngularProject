import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignupTDComponent } from './signup-td.component';

describe('SignupTDComponent', () => {
  let component: SignupTDComponent;
  let fixture: ComponentFixture<SignupTDComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignupTDComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupTDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
