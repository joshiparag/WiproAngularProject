import { GrosssalPipe } from './grosssal.pipe';

describe('GrosssalPipe', () => {
  it('create an instance', () => {
    const pipe = new GrosssalPipe();
    expect(pipe).toBeTruthy();
  });
});
