import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import {Employeedata} from '../employeedata'
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private dataservice:DataService) { }

  employeedetails : Employeedata[]

  getEmpDataFromService(){
    this.dataservice.getData().subscribe((data:Employeedata[])=>{
      console.log(data)
      this.employeedetails = data
    })
  }

  ngOnInit(): void {
    this.getEmpDataFromService()
  }

}
