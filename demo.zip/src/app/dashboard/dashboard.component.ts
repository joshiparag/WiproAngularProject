import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import {Employeedata} from '../employeedata'
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private dataservice:DataService) { }
  sal : number = 1000000
  bonus : number = 0.20
  employeedetails : Employeedata[]
  todayDate = new Date()

  deleteEmp(id){
    this.dataservice.deleteData(id).subscribe(()=>{
      
      alert("Employee:" + id + " Deleted ")

      this.getEmpDataFromService()
    })
  }

  getEmpDataFromService(){
    this.dataservice.getData().subscribe((data:Employeedata[])=>{
      console.log(data)
      this.employeedetails = data
    })
  }

  ngOnInit(): void {
    this.getEmpDataFromService()
  }

}
