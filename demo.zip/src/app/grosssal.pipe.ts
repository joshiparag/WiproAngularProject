import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'grosssal'
})
export class GrosssalPipe implements PipeTransform {
 bonus = 0.20
 hra = 0.15
 ta  = 0.20
 da = 0.18

 transform(value: number): number {
    var totalsal = value + (value*this.bonus + value*this.hra + value * this.ta + value*this.da)
    return totalsal;
  }

}
