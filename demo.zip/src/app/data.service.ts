import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import {Employeedata} from './employeedata'
import{throwError, Observable} from 'rxjs'
import {catchError} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class DataService {
  
  
  private apiserver : string = 'http://localhost:5555'

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  
  getData():Observable<Employeedata[]>{
    return this.http.get<Employeedata[]>(this.apiserver + "/employees/")
    .pipe(catchError(this.errorHandler))
  }

  constructor(private http:HttpClient) { }

  errorHandler(error){
    let errorMessage = ""
    if(error.error instanceof ErrorEvent){
      errorMessage = error.error.message
      
    }else{
      errorMessage =  `Error Code : ${error.status} \n Messsage : ${error.message}` 

    }
    console.log(errorMessage)
    return throwError(errorMessage)
  }

  
}
