export interface Employeedata{
    id:number;
    empname:string;
    password:string
    empemail:string;
    empdepartment:string;
    empsign:boolean;
}