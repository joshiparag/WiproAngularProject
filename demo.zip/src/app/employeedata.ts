export interface Employeedata{
    empname:string;
    emppassword:string
    empemail:string;
    empdepartent:string;
    empsign:boolean;
    id?:number;
}