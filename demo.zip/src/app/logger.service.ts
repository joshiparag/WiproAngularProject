import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class LoggerService {
logger:object = {
  loggerModule : "",
  loggerDesc: ""
}

logs = []

islogging:boolean = false

savelog(data){
  if(this.islogging)
  {
  this.logger = data
  this.logs.push(this.logger)
  }
}

getlogs(){
  return this.logs
}

  constructor() { }
}
