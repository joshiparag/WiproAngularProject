import { Component } from '@angular/core';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My Web';

  constructor(private authservice:AuthService){

  }
  login()
  {
    this.authservice.loggedIn()
    localStorage.setItem("userid","parag")
      }
  logout(){
    this.authservice.logout()
    localStorage.setItem("userid","guest")
  }

}
