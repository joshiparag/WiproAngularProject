import { Directive ,HostListener,ElementRef,Input} from '@angular/core';

@Directive({
  selector: '[appCustomstyle]'
})
export class CustomstyleDirective {

  constructor(private elementref:ElementRef) { }
  @Input() bgColor :string;
  @Input() Color : string;

  @HostListener('mouseenter')onMouseEnter(){
    this.elementref.nativeElement.style.fontWeight = 'bold'
    this.elementref.nativeElement.style.backgroundColor = this.bgColor
    this.elementref.nativeElement.style.color = this.Color
  }

  @HostListener('mouseleave')onMouseLeave(){
    this.elementref.nativeElement.style.fontWeight = 'normal'
    this.elementref.nativeElement.style.backgroundColor = "initial"
    this.elementref.nativeElement.style.color = "black"
  }



}
