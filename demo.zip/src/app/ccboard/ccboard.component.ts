import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ccboard',
  templateUrl: './ccboard.component.html',
  styleUrls: ['./ccboard.component.css']
})
export class CcboardComponent implements OnInit {
  height:number = 300
  width:number = 300
  height1:number = 200
  width1:number = 200

  src:string = "";
  imgsrc = "../assets/ck2.jpg"
  bike = "../assets/h1.jpg"
  car = "../assets/bmw.jpg"

  fvehicle:string = ""

  show(vtype){
    if(vtype == "car"){
      this.src = this.car
    }
    else{
      this.src = this.bike
    }
  }

  zoomin(h,w){
    this.height1=h
    this.width1 = w
  }

  zoomout(h,w){
    this.height1 =h
    this.width1 = w
  }

  constructor() {

      this.src = this.bike
   }

  ngOnInit(): void {
  }

}
