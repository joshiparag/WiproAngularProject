import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CcboardComponent } from './ccboard.component';

describe('CcboardComponent', () => {
  let component: CcboardComponent;
  let fixture: ComponentFixture<CcboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
