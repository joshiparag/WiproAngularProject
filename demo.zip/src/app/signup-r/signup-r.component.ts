import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Employee } from '../employee'
import { Employeedata} from '../employeedata'
import { LoggerService } from '../logger.service';
import { DataService } from '../data.service';
import {Router} from '@angular/router'
@Component({
  selector: 'app-signup-r',
  templateUrl: './signup-r.component.html',
  styleUrls: ['./signup-r.component.css']
})
export class SignupRComponent implements OnInit {
  departments: string[] = ["Information Technology",
    "Human Resource",
    "Research and Development",
    "IT Operations"]
  form: FormGroup
  employee: Employee;
  employeedata : Employeedata
  emp = [];
  error: string[] = []
  logs = []
  saveemployee() {
    this.loggerservice.savelog({
      loggerModule: 'Reactive',
      loggerDesc: ' Form Submitted..'
              });
      
    this.error = []
    if (this.form.value.empemail == "") {
      this.error.push("Email is mandatory")
    }
    if (this.form.value.empname == "") {
      this.error.push("username is mandatory")
    }
    if (this.form.valid) {
        this.employee = this.form.value
        //console.log(this.employee)
        this.employeedata = {
        empname : this.employee.empname,
        emppassword : this.employee.password.emppassword,
        empemail : this.employee.empemail,
        empdepartent : this.employee.empdepartment,
        empsign : this.employee.empsign
      }
      //this.emp.push(this.employee)
      this.dataservice.saveData(this.employeedata).subscribe(
        res =>{
          alert('Employee Registered into EMS')
          this.router.navigateByUrl('/dashboard')
        }
      )
        
      this.loggerservice.savelog({
        loggerModule: 'Reactive',
        loggerDesc: ' Form Saved'
                });
    }
    this.logs= this.loggerservice.getlogs()
    console.log(this.logs)
  }
  constructor(private router:Router,private loggerservice:LoggerService, private dataservice:DataService) {
    this.loggerservice.islogging = true
    this.loggerservice.savelog({
      loggerModule: 'Reactive',
      loggerDesc: ' Form Loaded'
              });
   }
  ngOnInit(): void {
    
    this.form = new FormGroup(
      {
        empname: new FormControl("", Validators.required),
        password: new FormGroup({
          emppassword: new FormControl('', [Validators.required, Validators.minLength(8)]),
          emprpassword: new FormControl('', Validators.required)
        }),
        empemail: new FormControl('', [Validators.required,
        Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
        empdepartment: new FormControl(this.departments[0]),
        empsign: new FormControl("", Validators.requiredTrue)
      })

    this.employee = new Employee({
      empname: "",
      password: { emppassword: "", emprpassword: "" }, empemail: ""
      , empdepartment: "", empsign: undefined
    });

  }
}