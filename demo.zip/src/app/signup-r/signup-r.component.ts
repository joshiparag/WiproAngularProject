import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Employee } from '../employee'
import { LoggerService } from '../logger.service';
@Component({
  selector: 'app-signup-r',
  templateUrl: './signup-r.component.html',
  styleUrls: ['./signup-r.component.css']
})
export class SignupRComponent implements OnInit {
  departments: string[] = ["Information Technology",
    "Human Resource",
    "Research and Development",
    "IT Operations"]
  form: FormGroup
  employee: Employee;
  emp = [];
  error: string[] = []
  logs = []
  saveemployee() {
    this.loggerservice.savelog({
      loggerModule: 'Reactive',
      loggerDesc: ' Form Submitted..'
              });
      
    this.error = []
    if (this.form.value.empemail == "") {
      this.error.push("Email is mandatory")
    }
    if (this.form.value.empname == "") {
      this.error.push("username is mandatory")
    }
    if (this.form.valid) {
      this.employee = this.form.value
      this.emp.push(this.employee)
      this.loggerservice.savelog({
        loggerModule: 'Reactive',
        loggerDesc: ' Form Saved'
                });
    }
    this.logs= this.loggerservice.getlogs()
    console.log(this.logs)
  }
  constructor(private loggerservice:LoggerService) {
    this.loggerservice.islogging = true
    this.loggerservice.savelog({
      loggerModule: 'Reactive',
      loggerDesc: ' Form Loaded'
              });
   }
  ngOnInit(): void {
    
    this.form = new FormGroup(
      {
        empname: new FormControl("", Validators.required),
        password: new FormGroup({
          emppassword: new FormControl('', [Validators.required, Validators.minLength(8)]),
          emprpassword: new FormControl('', Validators.required)
        }),
        empemail: new FormControl('', [Validators.required,
        Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
        empdepartment: new FormControl(this.departments[0]),
        empsign: new FormControl("", Validators.requiredTrue)
      })

    this.employee = new Employee({
      empname: "",
      password: { emppassword: "", emprpassword: "" }, empemail: ""
      , empdepartment: "", empsign: undefined
    });

  }
}