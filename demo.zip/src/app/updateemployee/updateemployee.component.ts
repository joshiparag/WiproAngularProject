import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'
import { Employeedata } from '../employeedata'
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { Employee } from '../employee'
import { DataService } from '../data.service';
@Component({
  selector: 'app-updateemployee',
  templateUrl: './updateemployee.component.html',
  styleUrls: ['./updateemployee.component.css']
})
export class UpdateemployeeComponent implements OnInit {
  id: number;
  employeedata: any = []
  employee: Employeedata
  form: FormGroup
  departments: string[] = ["Information Technology",
    "Human Resource",
    "Research and Development",
    "IT Operations"]

  constructor(private router: Router, private dataservice: DataService, private activatedroute: ActivatedRoute) { }
  saveemployee() {
    if (this.form.valid) {
      this.employee = {
        empname: this.form.value.empname,
        emppassword: this.form.value.password.emppassword,
        empemail: this.form.value.empemail,
        empdepartent: this.form.value.empdepartment,
        empsign: this.form.value.empsign
      }
      this.dataservice.updateData(this.id, this.employee).subscribe(
        res => {
          alert('Employee Record updated in EMS')
          this.router.navigateByUrl('/dashboard')
        }
      )
    }
    else {
      alert("Form Issues please correct")
    }

  }

  getEmployeeData() {
    this.activatedroute.params.subscribe(
      param => {
        this.id = param["id"]
        this.dataservice.getDataById(this.id).subscribe(
          (data) => {
            this.employeedata = data
            this.form = new FormGroup(
              {
                empid: new FormControl(this.employeedata.id),
                empname: new FormControl(this.employeedata.empname, Validators.required),
                password: new FormGroup({
                  emppassword: new FormControl(this.employeedata.emppassword, [Validators.required, Validators.minLength(8)]),
                  emprpassword: new FormControl(this.employeedata.emppassword, Validators.required)
                }),
                empemail: new FormControl(this.employeedata.empemail, [Validators.required,
                Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
                empdepartment: new FormControl(this.employeedata.empdepartent),
                empsign: new FormControl(this.employeedata.empsign, Validators.requiredTrue)
              })

          })
      })



  }

  ngOnInit(): void {
    this.getEmployeeData()
  }

}
