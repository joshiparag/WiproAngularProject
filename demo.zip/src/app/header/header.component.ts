import { Component, OnInit } from '@angular/core';
import { LoggerService } from '../logger.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  shopTitle : string = "Cakes and Pasteries"
  constructor(private loggerservice:LoggerService) { }
logs = []
  ngOnInit(): void {
    this.logs = this.loggerservice.getlogs()
  }

}
