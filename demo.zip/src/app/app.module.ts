import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CcboardComponent } from './ccboard/ccboard.component';
import { FormsModule } from  '@angular/forms';
import { RestaurantmenuComponent } from './restaurantmenu/restaurantmenu.component';
import { CustomstyleDirective } from './customstyle.directive';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { BootstrapdemoComponent } from './bootstrapdemo/bootstrapdemo.component';
import { SignupTDComponent } from './signup-td/signup-td.component';
import { SignupRComponent } from './signup-r/signup-r.component';
import { SignupComponent } from './signup/signup.component'
import {ReactiveFormsModule} from '@angular/forms'
import{LoggerService} from './logger.service';
import { DashboardComponent } from './dashboard/dashboard.component'
import {HttpClientModule} from '@angular/common/http'
import {DataService} from './data.service';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';
import { GrosssalPipe } from './grosssal.pipe'
import { AuthService } from './auth.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar'
import {MatButtonModule} from '@angular/material/button'
import {MatMenuModule} from '@angular/material/menu'

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CcboardComponent,
    RestaurantmenuComponent,
    CustomstyleDirective,
    PagenotfoundComponent,
    BootstrapdemoComponent,
    SignupTDComponent,
    SignupRComponent,
    SignupComponent,
    DashboardComponent,
    UpdateemployeeComponent,
    GrosssalPipe
  ],
  imports: [
    MatMenuModule,
    MatButtonModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatToolbarModule
  ],
  providers: [LoggerService,DataService,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
